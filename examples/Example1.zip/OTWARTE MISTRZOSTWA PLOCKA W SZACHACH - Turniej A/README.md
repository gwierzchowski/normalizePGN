### Prerequisites to run this example
- installed `python3` and packages `gamerec`, `normalizePGN` - if you read this file you probably have this (see main README.md file
  from normalizePGN package).
- unmodified configuration files `PGNChessGC.pgn`, `SQLiteChessGC.txt` placed under user home folder by 
  `gamerec` package installation (see main README.md file from gamerec package).
- SQLite command line interface `sqlite3` (`sqlite3.exe`) available on system PATH.  
  Linux: install from repositories (Debian and derivatives: `sudo apt-get install sqlite3`).  
  Windows: download zip-file titled "A bundle of command-line tools for managing SQLite database files" from
  [SQLite site](http://sqlite.org/download.html).
- recommended but not necessary (used in case of debugging/developing scripts): SQLite GUI interface: `sqlitebrowser`.  
  Linux: install from repositories (Debian and derivatives: `sudo apt-get install sqlitebrowser`).  
  Windows: download from project [home page](http://sqlitebrowser.org/).
- recommended but not necessary (used to ECO-classify games): SCID chess database.  
  Linux: install from repositories (Debian and derivatives: `sudo apt-get install scid`).  
  Windows: download from project [home page](http://scid.sourceforge.net/).

### Step-by-step instruction
I'm going to import games from tournament: [OTWARTE MISTRZOSTWA PŁOCKA W SZACHACH - Turniej A](http://chessarbiter.com/turnieje/2015/ti_2611/index.html?l=pl) to my chess database.

I'm doing following steps:
- create folder `OTWARTE MISTRZOSTWA PLOCKA W SZACHACH - Turniej A`.
- copy following files to it from previous edition of this tournament (or from some other tournament or from this example):
```
-rwxrwxr-x 1 grzegorz grzegorz   811 wrz 14  2013 fixtitle.py
-rw-rw-r-- 1 grzegorz grzegorz  1604 sty 30 14:07 lista.txt
-rwxrwxr-x 1 grzegorz grzegorz  1447 sty 17 21:15 normpgn1
-rwxrwxr-x 1 grzegorz grzegorz  1688 sty 24 22:20 normpgn2
-rwxrwxr-x 1 grzegorz grzegorz   432 sty 17 21:25 normpgn3
```
  note that some files must have executable attribute.
- download games from web page to this folder (file `file1.pgn`).
- from web browser copy [participant list](http://chessarbiter.com/turnieje/2015/ti_2611/results.html?l=pl&tb=2_) 
  to file `lista.txt`; pay attention that every line - especially first and last one is aligned uniformly with other ones - 
  enter/delete some spaces in need.
- open shell window in tournament folder and run command `./normpgn1 1`.
  It will create some files in tournament folder (in this example they are placed in `step1` folder).
- examine file `1test1.txt`. I don't like following:
  * event name is too long and miss "Group A" information
  * event site is bad
  * event date is not complete
  * time control is absent
  * ECO classification codes are not entered
- examine file `1test2.txt`. I don't like following:
  * some game dates are not complete
  * round and board information is concatenated into one tag; I would like to have it in separate tags (Round and Board)
- examine file `1test3.txt`. I don't like following:
  * player titles are absent
- open script file `normpgn2` for edition, write fix queries or instructions:
  * under `echo Fix test1` I wrote query that globally set tags to values I want (taken from tournament web page).
  * under `echo Fix test2` I wrote query that separate boards from rounds; note next out-commented query 
    that should be used as well in case we'd have more that 9 rounds
  * later i wrote queries that set proper game dates (correct dates are based on web page); 
    note that order of queries is important
  * under `echo Fix test3` there are 2 shell instructions:  
    * first one invokes sed program to: 
      * eliminate polish national characters from participant list (national characters are not officially allowed 
        in .pgn files and are not present in tournament game file)
      * drop out some columns and reformat participant list file to CSV format convenient for python code
    * second one invokes python script that set players titles based on participant list (prepared in previous instruction)
- then save the file and call it: `./normpgn2`;
  files created/changed by this call are for this example placed in `step2` folder
- run test again: `./normpgn1 2` and check in files `2test1.txt`, `2test2.txt`, `2test3.txt` that all issues were fixed;
  see folder `step3` for reference
- if there are still some issues correct `normpgn2` and run it again until all issues are fixed
- run `./normpgn3 -d`; it will export games to `normgames.pgn` file and delete spare files created by previous steps
- while looking at  file `1test1.txt` I noticed that "ECO codes are not entered", so additional steps are necessary;
  we use open source SCID program for that - this package is not that capable yet :)
  * open SCID and import `normgames.pgn` to clipbase (temporary database in memory)
  * in SCID invoke: File / Maintenance / ECO-Classify games, and then Tools / Export All Filter Games / Export to PGN file
- import final .pgn file to your chess database.
