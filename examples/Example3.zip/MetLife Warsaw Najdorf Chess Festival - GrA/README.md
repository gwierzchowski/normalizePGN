### Prerequisites to run this example
- installed `python3` and packages `gamerec`, `normalizePGN` - if you read this file you probably have this (see main README.md file
  from normalizePGN package).
- unmodified configuration files `PGNChessGC.pgn`, `SQLiteChessGC.txt` placed under user home folder by 
  `gamerec` package installation (see main README.md file from gamerec package).
- SQLite command line interface `sqlite3` (`sqlite3.exe`) available on system PATH.  
  Linux: install from repositories (Debian and derivatives: `sudo apt-get install sqlite3`).  
  Windows: download zip-file titled "A bundle of command-line tools for managing SQLite database files" from
  [SQLite site](http://sqlite.org/download.html).
- recommended but not necessary (used in case of debugging/developing scripts): SQLite GUI interface: `sqlitebrowser`.  
  Linux: install from repositories (Debian and derivatives: `sudo apt-get install sqlitebrowser`).  
  Windows: download from project [home page](http://sqlitebrowser.org/).
- recommended but not necessary (used to ECO-classify games): SCID chess database.  
  Linux: install from repositories (Debian and derivatives: `sudo apt-get install scid`).  
  Windows: download from project [home page](http://scid.sourceforge.net/).

### Step-by-step instruction
I'm going to import games from tournament: [MetLife Warsaw Najdorf Chess Festival - Gr. A](http://chessarbiter.com/turnieje/2014/ti_1759/) to my chess database.

I'm doing following steps:
- create folder `MetLife Warsaw Najdorf Chess Festival - GrA`.
- copy following files to it from previous edition of this tournament (or from some other tournament or from this eaxample):
```
-rwxrwxr-x 1 grzegorz grzegorz   811 wrz 14  2013 fixtitleelo.py
-rw-rw-r-- 1 grzegorz grzegorz  1604 sty 30 14:07 lista.txt
-rwxrwxr-x 1 grzegorz grzegorz  1447 sty 17 21:15 normpgn1
-rwxrwxr-x 1 grzegorz grzegorz  1688 sty 24 22:20 normpgn2
-rwxrwxr-x 1 grzegorz grzegorz   432 sty 17 21:25 normpgn3
```
  note that some files must have executable attribute.
- download games from [web page](http://www.poloniachess.pl/najdorf2014/index.php?page=partie) to this folder (file `a.pgn`).
- from web browser copy [participant list](http://chessarbiter.com/turnieje/2014/ti_1759/results.html?l=pl&tb=2_) 
  to file `lista.txt`; pay attention that every line - especially first and last one is aligned uniformly with other ones - 
  enter/delete some spaces in need; actually few records (eg. Lei, TingjieCHN) miss a title - I entered 2 spaces to properly parse file.
- open shell window in tournament folder and run command `./normpgn1 1`.
  It will create some files in tournament folder (in this example they are placed in `step1` folder).
- examine file `1test1.txt`. I don't like following:
  * event name is not consistent and miss group A information
  * event site is not consistent
  * event date is not complete or not set
  * time control is absent
  * there is one empty (vo) game.
  * ECO classification codes are not entered for some games
- examine file `1test2.txt`. I don't like following:
  * round and board information is concatenated into one tag for some games; I would like to have it in separate tags (Round and Board)
- examine file `1test3.txt`. I don't like following:
  * player titles and ELO are absent
- open script file `normpgn2` for edition, write fix queries or instructions:
  * under `echo Fix test1` I wrote query that globally set tags to values I want (taken from tournament web page).
  * also another query deleted empty/vo games
  * under `echo Fix test2` I wrote queries that separate boards from rounds
  * later i wrote queries that set proper game dates (correct dates are based on web page); 
    note that order of queries is important
  * under `echo Fix test3` there are some queries and 3 shell instructions:  
    * first instruction invokes sed program to: 
      * eliminate polish national characters from participant list (national characters are not officially allowed 
        in .pgn files and are not present in tournament game file)
      * drop out some columns and reformat participant list file to CSV format convenient for python code
    * second instruction invokes awk program to remove country suffexes from players' names
    * third instruction invokes python script that set players titles and elo based on participant list (prepared in previous instruction)
- then save the file and run it: `./normpgn2`;
  files created/changed by this call are for this example placed in `step2` folder
- run test again: `./normpgn1 2` and check in files `2test1.txt`, `2test2.txt`, `2test3.txt` that all issues were fixed;
  see folder `step3` for reference
- if there are still some issues correct `normpgn2` and run it again until all issues are fixed
- run `./normpgn3 -d`; it will export games to `normgames.pgn` file and delete spare files created by previous steps
- while looking at  file `1test1.txt` I noticed that "ECO codes are not entered", so additional steps are necessary;
  we use open source SCID program for that - this package is not that capable yet :)
  * open SCID and import `normgames.pgn` to clipbase (temporary database in memory)
  * in SCID invoke: File / Maintenance / ECO-Classify games, and then Tools / Export All Filter Games / Export to PGN file
- import final .pgn file to your chess database.
