#! /usr/bin/env python3
# -*- coding: UTF-8 -*-

import sys
import sqlite3

if (len(sys.argv) < 3):
    print ("Too few command line arguments, argv=", sys.argv)
    print ("Usage: fixtitleelo-3.py <PlayersList> <SQLiteFile>")
    sys.exit(1)

# Name -> (Title,ELO)
Players = dict()

file = open(sys.argv[1], "r")
for line in file:
    col = line.split('|')
    if len(col) > 3:
        Players[col[1]] = (col[0],col[3])
        #Players[col[1][:-3]] = (col[0],col[3]) # Alternative to awk invocation

con = sqlite3.connect(sys.argv[2])
for (player, prank) in Players.items():
    if (not prank[0] == None) and (not prank[0] == ""):
        con.execute("UPDATE Games SET WhiteTitle='{0}' WHERE White = '{1}' AND WhiteTitle ISNULL;".format(prank[0], player))
        con.execute("UPDATE Games SET BlackTitle='{0}' WHERE Black = '{1}' AND BlackTitle ISNULL;".format(prank[0], player))
    if (not prank[1] == None) and (not prank[1] == ""):
        con.execute("UPDATE Games SET WhiteElo='{0}' WHERE White = '{1}' AND WhiteElo ISNULL;".format(prank[1], player))
        con.execute("UPDATE Games SET BlackElo='{0}' WHERE Black = '{1}' AND BlackElo ISNULL;".format(prank[1], player))
con.commit()
